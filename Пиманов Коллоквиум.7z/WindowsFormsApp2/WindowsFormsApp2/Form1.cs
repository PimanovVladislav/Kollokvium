﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IStroka.Text != "")
            {
                char C;
                int B;
                string S = IStroka.Text;
                String S1="", M = "";
                for(int i=0;i<S.Length;i++)
                {
                    if (S[i] == ' ')
                    {
                        if (M != "")
                        {
                            B = M.Length - 1;
                            for (int j = 0; j < M.Length; j++)
                            {
                                if (M[j] == M[B] && j != B) S1 += '.';
                                else S1 += M[j];
                            }
                        }
                        S1 += ' ';
                        M = "";
                    }
                    else
                    {
                        M += S[i];
                    }
                }
                if (M != "")
                {
                    B = M.Length - 1;
                    for (int j = 0; j < M.Length; j++)
                    {
                        if (M[j] == M[B] && j != B) S1 += '.';
                        else S1 += M[j];
                    }
                }
                NewStroka.AppendText(S1 + "\n");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IStroka.Clear();
            NewStroka.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int M = 0, N = 0;
            int K1 = 0, K2 = 0;
            String S = Razm.Text, s="";
            for (int i = 0; i < S.Length; i++)
            {
                if (S[i] != ' ')
                {
                    if (M == 0)
                    {
                        
                        M = int.Parse(S[i]+" ");
                       
                    }
                    else
                    {
                       
                        N = int.Parse(S[i]+" ");
                        
                    }
                }
            }
            S = Stroki.Text;
            for (int i = 0; i < S.Length; i++)
            {
                if (S[i] != ' ' )
                {
                    if (K1 == 0)
                    {
                       
                        K1 = int.Parse(S[i] + " ");

                     
                    }
                    else
                    {

                        K2 = int.Parse(S[i]+" ");
                      
                    }
                }
            }
            K1--;K2--;
            char[,] mas = new char[M,N];
            int a = 0,b = 0;
            S = IMatrix.Text;
            for (int i = 0; i < S.Length; i++)
            {
                if (S[i] == ' ')
                {
                    a++;
                    
                }
                else
                {
                    if (S[i] == '\n')

                    {
                        b++;
                        a = 0;
                    }
                    else
                    {

                        mas[b, a] = S[i];

                    }
                }
            }
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (i == K1) NewMatrix.AppendText(mas[K2, j] + " ");
                    else
                    {
                        if (i == K2) NewMatrix.AppendText(mas[K1, j] + " ");
                        else
                            NewMatrix.AppendText(mas[i, j] + " ");
                    }
                }
                NewMatrix.AppendText("\n");
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Razm.Clear();
            Stroki.Clear();
            IMatrix.Clear();
            NewMatrix.Clear();
        }
    }
}
